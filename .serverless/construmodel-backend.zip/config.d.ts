export declare type Config = {
    [key: string]: any;
};
export declare const baseConfig: Config;
export declare const devConfig: Config;
export declare const testConfig: Config;
export declare const prodConfig: Config;
declare const _default: () => Config;
export default _default;

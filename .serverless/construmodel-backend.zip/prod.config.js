"use strict";
module.exports = {
    DB_PASSWORD: 'kodakFOX159',
    DB_HOST: 'construmodel.cehfjrs65lmb.us-west-2.rds.amazonaws.com',
    COOKIE_SECRET: '&%=#lzoR+<Qhc{a'
};
//# sourceMappingURL=prod.config.js.map
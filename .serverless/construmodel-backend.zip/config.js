"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.prodConfig = exports.testConfig = exports.devConfig = exports.baseConfig = void 0;
const prod_config_1 = require("./prod.config");
process.env.NODE_ENV = (_a = process.env.NODE_ENV) !== null && _a !== void 0 ? _a : 'dev';
exports.baseConfig = {
    DB_USER: process.env.USER,
    DB_SYNC: false,
    DB_HOST: 'localhost',
};
exports.devConfig = Object.assign(Object.assign({}, exports.baseConfig), { COOKIE_SECRET: 'fixme', DB_NAME: 'cm_dev', DB_SYNC: false, DB_LOG: true });
exports.testConfig = Object.assign(Object.assign({}, exports.baseConfig), { COOKIE_SECRET: 'secret', DB_NAME: 'cm_test', DB_SYNC: true });
exports.prodConfig = Object.assign(Object.assign(Object.assign({}, exports.baseConfig), { DB_NAME: 'postgres' }), prod_config_1.default);
let config;
switch (process.env.NODE_ENV) {
    case 'dev':
        config = exports.devConfig;
        break;
    case 'prod':
        config = exports.prodConfig;
        break;
    case 'test':
        config = exports.testConfig;
        break;
    default:
        throw new Error(`Unknown environment: ${process.env.NODE_ENV}`);
}
exports.default = () => config;
//# sourceMappingURL=config.js.map
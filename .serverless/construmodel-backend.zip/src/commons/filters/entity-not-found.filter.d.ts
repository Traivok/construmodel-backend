import { HttpStatus } from '@nestjs/common';
import { EntityBaseFilterFilter } from './entity-base.filter';
import { EntityNotFoundError } from 'typeorm';
export declare class EntityNotFoundFilter extends EntityBaseFilterFilter<EntityNotFoundError> {
    protected entityName: string;
    readonly httpCode = HttpStatus.NOT_FOUND;
    get message(): string;
    constructor(entityName?: string);
}

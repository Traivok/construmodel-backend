import { ArgumentsHost, ExceptionFilter, HttpStatus, Logger } from '@nestjs/common';
export declare abstract class EntityBaseFilterFilter<T> implements ExceptionFilter {
    protected entityName: string;
    protected readonly logger: Logger;
    abstract readonly httpCode: HttpStatus;
    checkException(e: T): boolean;
    protected constructor(entityName: string);
    catch(exception: T, host: ArgumentsHost): void;
}

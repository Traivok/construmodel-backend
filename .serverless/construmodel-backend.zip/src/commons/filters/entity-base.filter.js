"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EntityBaseFilterFilter = void 0;
const common_1 = require("@nestjs/common");
class EntityBaseFilterFilter {
    constructor(entityName) {
        this.entityName = entityName;
        this.logger = new common_1.Logger(EntityBaseFilterFilter.name);
    }
    checkException(e) {
        return true;
    }
    catch(exception, host) {
        const ctx = host.switchToHttp();
        const res = ctx.getResponse();
        const status = this.httpCode;
        if (this.checkException(exception)) {
            res.status(status)
                .json({
                statusCode: status,
            });
        }
        else {
            this.logger.error(exception);
            res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR)
                .json({
                statusCode: common_1.HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal Server Error',
            });
        }
    }
}
exports.EntityBaseFilterFilter = EntityBaseFilterFilter;
//# sourceMappingURL=entity-base.filter.js.map
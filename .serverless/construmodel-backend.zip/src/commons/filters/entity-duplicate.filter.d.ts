import { HttpStatus, Logger } from '@nestjs/common';
import { QueryFailedError } from 'typeorm';
import { EntityBaseFilterFilter } from './entity-base.filter';
export declare class EntityDuplicateFilter extends EntityBaseFilterFilter<QueryFailedError> {
    protected readonly logger: Logger;
    readonly httpCode = HttpStatus.CONFLICT;
    get message(): string;
    constructor(entityName?: string);
    checkException(e: QueryFailedError): boolean;
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaginationService = void 0;
const page_dto_1 = require("./page.dto");
const page_meta_dto_1 = require("./page-meta.dto");
const common_1 = require("@nestjs/common");
class PaginationService {
    constructor(args) {
        this.logger = new common_1.Logger(PaginationService.name);
        const { entityName = 'entity', orderBy = 'created_at' } = args !== null && args !== void 0 ? args : {};
        this.entityName = entityName;
        this.orderBy = orderBy;
    }
    async findAllPaginated(pageOptionsDto) {
        const queryBuilder = this.repo.createQueryBuilder(this.entityName);
        queryBuilder.orderBy(`${this.entityName}.${this.orderBy}`)
            .skip(pageOptionsDto.skip)
            .take(pageOptionsDto.take);
        const [entities, itemCount] = await queryBuilder.getManyAndCount();
        const pageMetaDto = new page_meta_dto_1.default({ itemCount, pageOptionsDto });
        return new page_dto_1.PageDto(entities, pageMetaDto);
    }
}
exports.PaginationService = PaginationService;
//# sourceMappingURL=pagination.service.js.map
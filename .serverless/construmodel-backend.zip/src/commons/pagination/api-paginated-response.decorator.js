"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiPaginatedResponse = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const page_dto_1 = require("./page.dto");
const ApiPaginatedResponse = (model) => (0, common_1.applyDecorators)((0, swagger_1.ApiExtraModels)(page_dto_1.PageDto, model), (0, swagger_1.ApiOkResponse)({
    description: 'Successfully received model list',
    schema: {
        required: ['data'],
        allOf: [
            { $ref: (0, swagger_1.getSchemaPath)(page_dto_1.PageDto) },
            {
                properties: {
                    data: {
                        type: 'array',
                        items: { $ref: (0, swagger_1.getSchemaPath)(model) },
                    },
                },
            },
        ],
    },
}));
exports.ApiPaginatedResponse = ApiPaginatedResponse;
//# sourceMappingURL=api-paginated-response.decorator.js.map
import { ObjectLiteral, Repository } from 'typeorm';
import { PageOptionsDto } from './page-options.dto';
import { PageDto } from './page.dto';
import { Logger } from '@nestjs/common';
interface PaginationServiceOptions {
    entityName?: string;
    orderBy?: string;
}
export declare abstract class PaginationService<T extends ObjectLiteral> {
    protected logger: Logger;
    protected readonly entityName: string;
    protected orderBy: string;
    protected constructor(args?: PaginationServiceOptions);
    protected abstract repo: Repository<T>;
    findAllPaginated(pageOptionsDto: PageOptionsDto): Promise<PageDto<T>>;
}
export {};

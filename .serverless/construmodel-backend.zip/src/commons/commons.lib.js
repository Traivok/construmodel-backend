"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.entitiesToDTOs = exports.IsNil = void 0;
const class_transformer_1 = require("class-transformer");
function IsNil(arg) {
    return arg === null || arg === undefined;
}
exports.IsNil = IsNil;
function entitiesToDTOs(entities, cls) {
    var _a;
    return (_a = entities === null || entities === void 0 ? void 0 : entities.map(e => (0, class_transformer_1.plainToInstance)(cls, e, { excludeExtraneousValues: true }))) !== null && _a !== void 0 ? _a : [];
}
exports.entitiesToDTOs = entitiesToDTOs;
//# sourceMappingURL=commons.lib.js.map
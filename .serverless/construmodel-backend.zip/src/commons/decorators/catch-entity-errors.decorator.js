"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CatchEntityErrors = void 0;
const common_1 = require("@nestjs/common");
const entity_duplicate_filter_1 = require("../filters/entity-duplicate.filter");
const entity_not_found_filter_1 = require("../filters/entity-not-found.filter");
const CatchEntityErrors = (entityName) => (0, common_1.applyDecorators)((0, common_1.UseFilters)(new entity_duplicate_filter_1.EntityDuplicateFilter(entityName), new entity_not_found_filter_1.EntityNotFoundFilter(entityName)));
exports.CatchEntityErrors = CatchEntityErrors;
//# sourceMappingURL=catch-entity-errors.decorator.js.map
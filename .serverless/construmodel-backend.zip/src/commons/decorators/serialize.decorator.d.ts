import { ClassConstructor } from 'class-transformer';
import { ApiResponseOptions } from '@nestjs/swagger';
export declare function Serialize<DTO>(dto: ClassConstructor<DTO>, options?: ApiResponseOptions): <TFunction extends Function, Y>(target: object | TFunction, propertyKey?: string | symbol | undefined, descriptor?: TypedPropertyDescriptor<Y> | undefined) => void;

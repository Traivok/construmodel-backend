"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiExposedProperty = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const ApiExposedProperty = (options) => (0, common_1.applyDecorators)((0, swagger_1.ApiProperty)(options === null || options === void 0 ? void 0 : options.apiOptions), (0, class_transformer_1.Expose)(options === null || options === void 0 ? void 0 : options.exposeOptions));
exports.ApiExposedProperty = ApiExposedProperty;
//# sourceMappingURL=api-exposed-property.decorator.js.map
import { ApiPropertyOptions } from '@nestjs/swagger';
import { ExposeOptions } from 'class-transformer';
export interface ApiExposedPropertyOptions {
    apiOptions?: ApiPropertyOptions;
    exposeOptions?: ExposeOptions;
}
export declare const ApiExposedProperty: (options?: ApiExposedPropertyOptions) => <TFunction extends Function, Y>(target: object | TFunction, propertyKey?: string | symbol | undefined, descriptor?: TypedPropertyDescriptor<Y> | undefined) => void;

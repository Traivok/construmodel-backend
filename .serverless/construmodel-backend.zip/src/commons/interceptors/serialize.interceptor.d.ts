import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { ClassConstructor } from 'class-transformer';
export declare class SerializeInterceptor<DTO> implements NestInterceptor {
    private dto;
    constructor(dto: ClassConstructor<DTO>);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
}

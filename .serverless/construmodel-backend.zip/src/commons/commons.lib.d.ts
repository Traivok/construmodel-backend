import { ClassConstructor } from 'class-transformer';
export declare function IsNil(arg: any): boolean;
export declare function entitiesToDTOs<DTO, ENT>(entities: ENT[], cls: ClassConstructor<DTO>): DTO[];

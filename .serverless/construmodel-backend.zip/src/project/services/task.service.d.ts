import { Repository } from 'typeorm';
import { Task } from '../entities/task.entity';
import { WorkFront } from '../entities/work-front.entity';
import { Sprint } from '../entities/sprint.entity';
export declare class TaskService {
    repository: Repository<Task>;
    private readonly logger;
    constructor(repository: Repository<Task>);
    update(done: number, workFront: WorkFront, sprints: Sprint[]): Promise<Task[]>;
}

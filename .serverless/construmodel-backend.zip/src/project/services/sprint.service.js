"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SprintService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SprintService = void 0;
const common_1 = require("@nestjs/common");
const sprint_entity_1 = require("../entities/sprint.entity");
const work_front_entity_1 = require("../entities/work-front.entity");
const fp_1 = require("date-fns/fp");
const date_fns_1 = require("date-fns");
const typeorm_1 = require("typeorm");
const typeorm_2 = require("@nestjs/typeorm");
const papaparse_1 = require("papaparse");
const work_front_service_1 = require("./work-front.service");
const task_service_1 = require("./task.service");
const task_entity_1 = require("../entities/task.entity");
let SprintService = SprintService_1 = class SprintService {
    constructor(repository, dataSource, workFrontService, taskService) {
        this.repository = repository;
        this.dataSource = dataSource;
        this.workFrontService = workFrontService;
        this.taskService = taskService;
        this.logger = new common_1.Logger(SprintService_1.name);
    }
    async find() {
        return this.repository.find({
            relations: ['tasks', 'tasks.workFront'],
        });
    }
    async findOrFail(id) {
        return await this.repository.findOneOrFail({
            where: { id },
            relations: ['tasks', 'tasks.workFront'],
        });
    }
    async createSprint(dto) {
        const sprint = this.repository.create(this.fixDates(dto));
        return await this.repository.save(sprint);
    }
    async createMultiple(dtos) {
        const sprints = this.repository.create(dtos.map(dto => this.fixDates(dto)));
        return await this.repository.save(sprints);
    }
    async findNewerThan(date) {
        return await this.repository.find({
            where: {
                start: (0, typeorm_1.MoreThanOrEqual)(date),
            },
            relations: ['tasks'],
        });
    }
    async findPrevious() {
        const older = (a, b) => a.start.getTime() < b.start.getTime() ? a : b;
        const sprints = await this.find();
        return sprints.filter(s => s.status === sprint_entity_1.SprintStatus.PAST)
            .reduce((prev, curr) => prev === null ? curr : older(prev, curr), null);
    }
    async findCurrent() {
        var _a;
        const sprints = await this.find();
        return (_a = sprints.find(s => s.status === sprint_entity_1.SprintStatus.CURRENT)) !== null && _a !== void 0 ? _a : null;
    }
    async findNext() {
        const newer = (a, b) => a.start.getTime() >= b.start.getTime() ? a : b;
        const sprints = await this.find();
        return sprints.filter(s => s.status === sprint_entity_1.SprintStatus.FUTURE)
            .reduce((prev, curr) => prev === null ? curr : newer(prev, curr), null);
    }
    normalizeStart(start) {
        let date = start;
        if (!(0, fp_1.isSunday)(start))
            date = (0, date_fns_1.previousSunday)(start);
        date.setHours(0, 0, 0, 0);
        return date;
    }
    getEndByStart(start) {
        const date = (0, date_fns_1.nextSaturday)(start);
        date.setHours(23, 59, 59, 999);
        return date;
    }
    fixDates(dto) {
        dto.start = this.normalizeStart(dto.start);
        return Object.assign(Object.assign({}, dto), { end: this.getEndByStart(dto.start) });
    }
    parseCsvProject(csvString) {
        const { errors, data, meta: { fields } } = (0, papaparse_1.parse)(csvString, {
            header: true,
            skipEmptyLines: true,
            complete: results => results.data,
        });
        if (Array.isArray(errors) && errors.length > 0) {
            throw new common_1.BadRequestException(errors.map(e => e.message));
        }
        if (Array.isArray(fields) && fields.length > 1) {
            const [dateColName, ...workFronts] = fields;
            return {
                sprints: data.map(d => (Object.assign({}, this.fixDates({ start: SprintService_1.ptDateStrToDate(d[dateColName]) })))),
                dateColName,
                data,
                workFronts: workFronts.map(name => ({
                    name,
                    floors: parseFloat(data[data.length - 1][name]),
                })),
            };
        }
        else {
            throw new common_1.BadRequestException('Invalid CSV headers');
        }
    }
    async createProject(parsed) {
        return await this.dataSource.manager.transaction(async (entityManager) => {
            await entityManager.query('TRUNCATE TABLE work_front RESTART IDENTITY CASCADE');
            await entityManager.query('TRUNCATE TABLE sprint RESTART IDENTITY CASCADE');
            const workFronts = await entityManager.save(work_front_entity_1.WorkFront, entityManager.create(work_front_entity_1.WorkFront, parsed.workFronts));
            const sprints = await entityManager.save(sprint_entity_1.Sprint, entityManager.create(sprint_entity_1.Sprint, parsed.sprints));
            sprints.sort((a, b) => a.start.getTime() - b.start.getTime());
            for (const datum of parsed.data) {
                const date = SprintService_1.ptDateStrToDate(datum[parsed.dateColName]);
                const sprint = SprintService_1.findSorted(sprints, this.normalizeStart(date));
                if (sprint === null)
                    throw new common_1.BadRequestException(`Invalid date for ${date}`);
                const tasks = workFronts.map(wf => ({
                    sprint,
                    sprintId: sprint.id,
                    workFrontName: wf.name,
                    workFront: wf,
                    planned: parseFloat(datum[wf.name]),
                }));
                const taskEntities = entityManager.create(task_entity_1.Task, tasks);
                await entityManager.save(taskEntities);
            }
            return await entityManager.find(sprint_entity_1.Sprint, {
                relations: ['tasks', 'tasks.workFront'],
            });
        });
    }
    static ptDateStrToDate(ptDate) {
        return new Date(ptDate.split('/').reverse().join('/'));
    }
    static findSorted(sprints, startDate, start = 0, end = sprints.length - 1) {
        const mid = Math.floor((start + end) / 2.);
        if (startDate.getTime() === sprints[mid].start.getTime())
            return sprints[mid];
        else if (start >= end)
            return null;
        return startDate.getTime() < sprints[mid].start.getTime() ?
            SprintService_1.findSorted(sprints, startDate, start, mid - 1) :
            SprintService_1.findSorted(sprints, startDate, mid + 1, end);
    }
};
SprintService = SprintService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_2.InjectRepository)(sprint_entity_1.Sprint)),
    __param(1, (0, typeorm_2.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_1.Repository,
        typeorm_1.DataSource,
        work_front_service_1.WorkFrontService,
        task_service_1.TaskService])
], SprintService);
exports.SprintService = SprintService;
//# sourceMappingURL=sprint.service.js.map
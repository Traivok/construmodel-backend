import { Sprint } from '../entities/sprint.entity';
import { CreateSprintDto } from '../dto/create-sprint.dto';
import { DataSource, DeepPartial, Repository } from 'typeorm';
import { ParsedProject } from '../interfaces/parsed-project';
import { WorkFrontService } from './work-front.service';
import { TaskService } from './task.service';
export declare class SprintService {
    repository: Repository<Sprint>;
    private dataSource;
    private workFrontService;
    private taskService;
    private readonly logger;
    constructor(repository: Repository<Sprint>, dataSource: DataSource, workFrontService: WorkFrontService, taskService: TaskService);
    find(): Promise<Sprint[]>;
    findOrFail(id: number): Promise<Sprint>;
    createSprint(dto: CreateSprintDto): Promise<Sprint>;
    createMultiple(dtos: CreateSprintDto[]): Promise<Sprint[]>;
    findNewerThan(date: Date): Promise<Sprint[]>;
    findPrevious(): Promise<Sprint | null>;
    findCurrent(): Promise<Sprint | null>;
    findNext(): Promise<Sprint | null>;
    protected normalizeStart(start: Date): Date;
    protected getEndByStart(start: Date): Date;
    protected fixDates(dto: CreateSprintDto): DeepPartial<Sprint>;
    parseCsvProject(csvString: string): ParsedProject;
    createProject(parsed: ParsedProject): Promise<Sprint[]>;
    private static ptDateStrToDate;
    private static findSorted;
}

import { WorkFront } from '../entities/work-front.entity';
import { CreateWorkFrontDto } from '../dto/create-work-front.dto';
import { Repository } from 'typeorm';
export declare class WorkFrontService {
    repository: Repository<WorkFront>;
    private readonly logger;
    constructor(repository: Repository<WorkFront>);
    create(createDto: CreateWorkFrontDto): Promise<WorkFront>;
    createMultiple(dtos: CreateWorkFrontDto[]): Promise<WorkFront[]>;
    findAll(): Promise<WorkFront[]>;
    findOrFail(name: string): Promise<WorkFront>;
}

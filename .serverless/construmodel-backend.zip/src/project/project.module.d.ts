export declare class ProjectModule {
}

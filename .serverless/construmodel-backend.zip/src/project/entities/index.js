"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectEntities = void 0;
const work_front_entity_1 = require("./work-front.entity");
const sprint_entity_1 = require("./sprint.entity");
const task_entity_1 = require("./task.entity");
exports.ProjectEntities = [
    work_front_entity_1.WorkFront,
    sprint_entity_1.Sprint,
    task_entity_1.Task,
];
//# sourceMappingURL=index.js.map
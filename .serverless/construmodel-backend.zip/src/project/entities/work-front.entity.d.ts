import { Task } from './task.entity';
export declare const WorkFront_NAME_LENGTH = 128;
export declare class WorkFront {
    name: string;
    floors: number;
    tasks: Task[];
}

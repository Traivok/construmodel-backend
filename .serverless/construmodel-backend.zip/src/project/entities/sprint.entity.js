"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sprint = exports.SprintStatus = void 0;
const typeorm_1 = require("typeorm");
const task_entity_1 = require("./task.entity");
var SprintStatus;
(function (SprintStatus) {
    SprintStatus["FUTURE"] = "FUTURE";
    SprintStatus["CURRENT"] = "CURRENT";
    SprintStatus["PAST"] = "PAST";
})(SprintStatus = exports.SprintStatus || (exports.SprintStatus = {}));
let Sprint = class Sprint {
    get status() {
        const now = Date.now();
        const start = this.start.getTime();
        const end = this.end.getTime();
        if (start < now && now <= end)
            return SprintStatus.CURRENT;
        else if (end < now)
            return SprintStatus.FUTURE;
        else
            return SprintStatus.PAST;
    }
    get progress() {
        if (!Array.isArray(this.tasks))
            return { done: 1, planned: 1, late: false };
        const { done, planned } = this.tasks.reduce((prev, curr) => ({
            planned: prev.planned + curr.planned / curr.workFront.floors,
            done: prev.done + curr.done / curr.workFront.floors,
        }), { done: 0, planned: 0 });
        return {
            done: done / this.tasks.length,
            planned: planned / this.tasks.length,
            late: done < planned,
        };
    }
};
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Sprint.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: false, unique: true }),
    __metadata("design:type", Date)
], Sprint.prototype, "start", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: false, unique: true }),
    __metadata("design:type", Date)
], Sprint.prototype, "end", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => task_entity_1.Task, task => task.sprint),
    __metadata("design:type", Array)
], Sprint.prototype, "tasks", void 0);
Sprint = __decorate([
    (0, typeorm_1.Entity)('sprint'),
    (0, typeorm_1.Check)(' "start" < "end" ')
], Sprint);
exports.Sprint = Sprint;
//# sourceMappingURL=sprint.entity.js.map
import { WorkFront } from './work-front.entity';
import { Sprint } from './sprint.entity';
export declare class Task {
    workFrontName: string;
    workFront: WorkFront;
    sprintId: number;
    sprint: Sprint;
    planned: number;
    done: number;
    get late(): boolean;
    createdAt: Date;
    updatedAt: Date;
}

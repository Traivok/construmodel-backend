import { WorkFront } from './work-front.entity';
import { Sprint } from './sprint.entity';
import { Task } from './task.entity';
export declare const ProjectEntities: (typeof Sprint | typeof Task | typeof WorkFront)[];

import { Task } from './task.entity';
export declare enum SprintStatus {
    FUTURE = "FUTURE",
    CURRENT = "CURRENT",
    PAST = "PAST"
}
export declare class Sprint {
    id: number;
    start: Date;
    end: Date;
    tasks: Task[];
    get status(): SprintStatus;
    get progress(): {
        late: boolean;
        planned: number;
        done: number;
    };
}

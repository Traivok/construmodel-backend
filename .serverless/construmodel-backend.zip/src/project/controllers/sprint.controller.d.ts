/// <reference types="multer" />
import { SprintService } from '../services/sprint.service';
import { Sprint } from '../entities/sprint.entity';
import { CreateProjectDto } from '../dto/create-project.dto';
export declare class SprintController {
    sprintService: SprintService;
    private readonly logger;
    constructor(sprintService: SprintService);
    find(): Promise<Sprint[]>;
    findPrevious(): Promise<Sprint | null>;
    findCurrent(): Promise<Sprint | null>;
    findNext(): Promise<Sprint | null>;
    findOne(id: number): Promise<Sprint>;
    createProject(body: CreateProjectDto, file: Express.Multer.File): Promise<Sprint[]>;
}

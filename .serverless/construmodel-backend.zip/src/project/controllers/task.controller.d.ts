import { SprintService } from '../services/sprint.service';
import { TaskService } from '../services/task.service';
import { WorkFrontService } from '../services/work-front.service';
import { UpdateTaskDto } from '../dto/update-task.dto';
export declare class TaskController {
    private sprintService;
    private taskService;
    private workFrontService;
    private readonly logger;
    constructor(sprintService: SprintService, taskService: TaskService, workFrontService: WorkFrontService);
    update(updateDto: UpdateTaskDto): Promise<void>;
}

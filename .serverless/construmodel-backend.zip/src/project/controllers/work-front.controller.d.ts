import { WorkFrontService } from '../services/work-front.service';
import { CreateWorkFrontDto } from '../dto/create-work-front.dto';
import { WorkFront } from '../entities/work-front.entity';
export declare class WorkFrontController {
    workFrontService: WorkFrontService;
    private readonly logger;
    constructor(workFrontService: WorkFrontService);
    createWorkFront(createDto: CreateWorkFrontDto): Promise<WorkFront>;
    findAll(): Promise<WorkFront[]>;
}

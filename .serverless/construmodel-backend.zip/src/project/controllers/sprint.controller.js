"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SprintController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SprintController = void 0;
const common_1 = require("@nestjs/common");
const sprint_service_1 = require("../services/sprint.service");
const swagger_1 = require("@nestjs/swagger");
const platform_express_1 = require("@nestjs/platform-express");
const serialize_decorator_1 = require("../../commons/decorators/serialize.decorator");
const sprint_dto_1 = require("../dto/sprint.dto");
const create_project_dto_1 = require("../dto/create-project.dto");
let SprintController = SprintController_1 = class SprintController {
    constructor(sprintService) {
        this.sprintService = sprintService;
        this.logger = new common_1.Logger(SprintController_1.name);
    }
    async find() {
        return await this.sprintService.find();
    }
    async findPrevious() {
        return await this.sprintService.findPrevious();
    }
    async findCurrent() {
        return await this.sprintService.findCurrent();
    }
    async findNext() {
        return await this.sprintService.findNext();
    }
    async findOne(id) {
        return await this.sprintService.findOrFail(id);
    }
    async createProject(body, file) {
        const csv = file.buffer.toString();
        const parsed = this.sprintService.parseCsvProject(csv);
        return await this.sprintService.createProject(parsed);
    }
};
__decorate([
    (0, common_1.Get)(),
    (0, serialize_decorator_1.Serialize)(sprint_dto_1.SprintDto),
    (0, swagger_1.ApiResponse)({ status: common_1.HttpStatus.OK, type: sprint_dto_1.SprintDto, isArray: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SprintController.prototype, "find", null);
__decorate([
    (0, common_1.Get)('previous'),
    (0, serialize_decorator_1.Serialize)(sprint_dto_1.SprintDto),
    (0, swagger_1.ApiResponse)({ status: common_1.HttpStatus.OK, type: sprint_dto_1.SprintDto }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SprintController.prototype, "findPrevious", null);
__decorate([
    (0, common_1.Get)('current'),
    (0, serialize_decorator_1.Serialize)(sprint_dto_1.SprintDto),
    (0, swagger_1.ApiResponse)({ status: common_1.HttpStatus.OK, type: sprint_dto_1.SprintDto }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SprintController.prototype, "findCurrent", null);
__decorate([
    (0, common_1.Get)('next'),
    (0, serialize_decorator_1.Serialize)(sprint_dto_1.SprintDto),
    (0, swagger_1.ApiResponse)({ status: common_1.HttpStatus.OK, type: sprint_dto_1.SprintDto }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SprintController.prototype, "findNext", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, serialize_decorator_1.Serialize)(sprint_dto_1.SprintDto),
    (0, swagger_1.ApiResponse)({ status: common_1.HttpStatus.OK, type: sprint_dto_1.SprintDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], SprintController.prototype, "findOne", null);
__decorate([
    (0, common_1.Put)(),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, serialize_decorator_1.Serialize)(sprint_dto_1.SprintDto),
    (0, swagger_1.ApiResponse)({ status: common_1.HttpStatus.CREATED, type: sprint_dto_1.SprintDto, isArray: true }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_project_dto_1.CreateProjectDto, Object]),
    __metadata("design:returntype", Promise)
], SprintController.prototype, "createProject", null);
SprintController = SprintController_1 = __decorate([
    (0, swagger_1.ApiTags)('sprint'),
    (0, common_1.Controller)('sprint'),
    __metadata("design:paramtypes", [sprint_service_1.SprintService])
], SprintController);
exports.SprintController = SprintController;
//# sourceMappingURL=sprint.controller.js.map
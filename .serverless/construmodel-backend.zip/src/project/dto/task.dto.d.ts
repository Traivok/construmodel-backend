export declare class TaskDto {
    workFrontName: string;
    planned: number;
    done: number;
    late: boolean;
}

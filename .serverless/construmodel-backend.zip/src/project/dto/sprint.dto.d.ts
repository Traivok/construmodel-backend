import { TaskDto } from './task.dto';
import { SprintStatus } from '../entities/sprint.entity';
export declare class SprintDto {
    id: number;
    start: Date;
    end: Date;
    tasks: TaskDto[];
    status: SprintStatus;
    progress: {
        done: number;
        planned: number;
        late: boolean;
    };
}

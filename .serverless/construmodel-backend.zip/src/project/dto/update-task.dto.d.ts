export declare class UpdateTaskDto {
    workFrontName: string;
    done: number;
    date: Date;
}

/// <reference types="multer" />
export declare class CreateProjectDto {
    file: Express.Multer.File;
}

export declare class CreateWorkFrontDto {
    name: string;
    floors: number;
}

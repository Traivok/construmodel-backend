export declare class CreateSprintDto {
    start: Date;
}

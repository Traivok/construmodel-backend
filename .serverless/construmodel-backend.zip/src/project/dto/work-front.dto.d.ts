export declare class WorkFrontDto {
    name: string;
    floors: number;
}

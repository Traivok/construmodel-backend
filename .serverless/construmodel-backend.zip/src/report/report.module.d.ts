export declare class ReportModule {
}

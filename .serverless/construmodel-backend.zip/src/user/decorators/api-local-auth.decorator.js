"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiLocalAuth = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const ApiLocalAuth = () => (0, common_1.applyDecorators)((0, common_1.UseGuards)((0, passport_1.AuthGuard)('local')));
exports.ApiLocalAuth = ApiLocalAuth;
//# sourceMappingURL=api-local-auth.decorator.js.map
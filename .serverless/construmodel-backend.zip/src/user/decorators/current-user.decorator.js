"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentUser = void 0;
const common_1 = require("@nestjs/common");
exports.CurrentUser = (0, common_1.createParamDecorator)((data, context) => {
    const request = context.switchToHttp().getRequest();
    if (request.currentUser === undefined)
        throw new common_1.UnauthorizedException('No current user was found');
    return request.currentUser;
});
//# sourceMappingURL=current-user.decorator.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiJwtAuth = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const passport_1 = require("@nestjs/passport");
const ApiJwtAuth = () => (0, common_1.applyDecorators)((0, swagger_1.ApiBearerAuth)('access_token'), (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')));
exports.ApiJwtAuth = ApiJwtAuth;
//# sourceMappingURL=api-jwt-auth.decorator.js.map
import { JwtPayloadDto } from '../dtos/jwt-payload.dto';
import { User } from '../entities/user.entity';
export declare namespace Express {
    interface Request {
        user?: JwtPayloadDto;
        currentUser?: User;
    }
}

import { UserService } from '../services/user.service';
import { UserDto } from '../dtos/user.dto';
import { AuthService } from '../services/auth.service';
import { JwtDto } from '../dtos/jwt.dto';
import { Express } from '../interfaces/request.interface';
import { RegisterDto } from '../dtos/register.dto';
export declare class AuthController {
    private authService;
    private userService;
    private readonly logger;
    constructor(authService: AuthService, userService: UserService);
    login(req: Express.Request, session: Record<string, any>): Promise<JwtDto>;
    register(newUser: RegisterDto): Promise<UserDto>;
    profile(req: Express.Request): Promise<UserDto>;
}

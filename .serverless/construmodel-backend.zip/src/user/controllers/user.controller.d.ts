import { User } from '../entities/user.entity';
import { UserService } from '../services/user.service';
import { AuthService } from '../services/auth.service';
import { UserDto } from '../dtos/user.dto';
import { PageOptionsDto } from '../../commons/pagination/page-options.dto';
import { PageDto } from '../../commons/pagination/page.dto';
import { UpdateUserDto } from '../dtos/update-user.dto';
export declare class UserController {
    private userService;
    private authService;
    private readonly logger;
    constructor(userService: UserService, authService: AuthService);
    findAll(pageOptions: PageOptionsDto): Promise<PageDto<UserDto>>;
    findOne(id: number): Promise<UserDto>;
    update(id: number, updateUserDto: UpdateUserDto, currentUser: User): Promise<UserDto>;
    remove(id: number, currentUser: User): Promise<void>;
}

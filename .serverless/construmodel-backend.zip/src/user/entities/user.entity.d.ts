import { UserRoles } from '../enums/user-roles';
export declare class User {
    private readonly logger;
    id: number;
    firstname: string;
    lastname: string;
    email: string;
    username: string;
    password: string;
    role: UserRoles;
    createdAt: Date;
    logRemoval(): void;
}

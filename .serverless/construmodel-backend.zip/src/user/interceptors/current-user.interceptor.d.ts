import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { UserService } from '../services/user.service';
import { Observable } from 'rxjs';
export declare class CurrentUserInterceptor implements NestInterceptor {
    private userService;
    constructor(userService: UserService);
    intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>>;
}

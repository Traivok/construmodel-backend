"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRoles = void 0;
var UserRoles;
(function (UserRoles) {
    UserRoles["USER"] = "User";
    UserRoles["ADMIN"] = "Admin";
})(UserRoles = exports.UserRoles || (exports.UserRoles = {}));
//# sourceMappingURL=user-roles.js.map
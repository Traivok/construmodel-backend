export declare enum UserRoles {
    USER = "User",
    ADMIN = "Admin"
}

import { Strategy } from 'passport-local';
import { AuthService } from '../services/auth.service';
import { User } from '../entities/user.entity';
declare const LocalStrategyService_base: new (...args: any[]) => Strategy;
export declare class LocalStrategyService extends LocalStrategyService_base {
    private authService;
    private readonly logger;
    constructor(authService: AuthService);
    validate(login: string, password: string): Promise<User>;
}
export {};

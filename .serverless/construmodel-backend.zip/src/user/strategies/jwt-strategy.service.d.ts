import { Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service';
import { JwtPayloadDto } from '../dtos/jwt-payload.dto';
declare const JwtStrategyService_base: new (...args: any[]) => Strategy;
export declare class JwtStrategyService extends JwtStrategyService_base {
    protected configService: ConfigService;
    private authService;
    private userService;
    constructor(configService: ConfigService, authService: AuthService, userService: UserService);
    validate(payload: JwtPayloadDto): Promise<{
        id: number;
        role: import("../enums/user-roles").UserRoles;
    } | null>;
}
export {};

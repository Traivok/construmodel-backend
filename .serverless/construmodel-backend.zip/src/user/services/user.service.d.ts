import { CreateUserDto } from '../dtos/create-user.dto';
import { User } from '../entities/user.entity';
import { PaginationService } from '../../commons/pagination/pagination.service';
import { Repository } from 'typeorm';
import { UpdateUserDto } from '../dtos/update-user.dto';
export declare class UserService extends PaginationService<User> {
    protected readonly repo: Repository<User>;
    constructor(repo: Repository<User>);
    create(createUserDto: CreateUserDto): Promise<User>;
    update(id: number, updateUserDto: UpdateUserDto): Promise<User>;
    remove(id: number): Promise<User>;
    findAll(): Promise<User[]>;
    findOne(id: number): Promise<User | null>;
    findOneOrFail(id: number): Promise<User>;
    checkOwnership(target_id: number, actor: User): void;
}

import { User } from '../entities/user.entity';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { JwtFromRequestFunction } from 'passport-jwt';
import { UserService } from './user.service';
import { AuthDto } from '../dtos/auth.dto';
import { JwtDto } from '../dtos/jwt.dto';
import { UpdateUserDto } from '../dtos/update-user.dto';
import { RegisterDto } from '../dtos/register.dto';
export declare class AuthService {
    private userRepo;
    private userService;
    private jwtService;
    private readonly logger;
    constructor(userRepo: Repository<User>, userService: UserService, jwtService: JwtService);
    login(auth: AuthDto): Promise<User>;
    loginJwt(user: User): Promise<JwtDto>;
    register(createUser: RegisterDto): Promise<User>;
    private static hash;
    update(id: number, updateUser: UpdateUserDto): Promise<User>;
    getJwtFromSession(session: Record<string, any>): JwtDto | null;
    setJwtToSession(session: Record<string, any>, jwt: JwtDto): Record<string, any>;
    removeJwtOfSession(session: Record<string, any>): void;
    fromSessionAsBearerToken(): JwtFromRequestFunction;
    getExtractingMethods(): JwtFromRequestFunction;
}

export declare class JwtDto {
    access_token: string;
}

import { UserRoles } from '../enums/user-roles';
export declare class JwtPayloadDto {
    id: number;
    role?: UserRoles;
}

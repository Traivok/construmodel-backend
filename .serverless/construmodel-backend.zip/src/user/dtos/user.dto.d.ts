import { UserRoles } from '../enums/user-roles';
export declare class UserDto {
    id: number;
    firstname: string;
    lastname: string;
    email: string;
    username: string;
    role: UserRoles;
    createdAt: Date;
}

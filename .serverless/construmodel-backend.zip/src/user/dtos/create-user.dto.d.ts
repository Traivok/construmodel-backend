import { UserRoles } from '../enums/user-roles';
export declare class CreateUserDto {
    firstname: string;
    lastname: string;
    email: string;
    username: string;
    password: string;
    role: UserRoles;
}

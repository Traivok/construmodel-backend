export declare class AuthDto {
    login: string;
    password: string;
}

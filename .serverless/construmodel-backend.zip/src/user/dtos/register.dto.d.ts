export declare class RegisterDto {
    firstname: string;
    lastname: string;
    email: string;
    username: string;
    password: string;
}

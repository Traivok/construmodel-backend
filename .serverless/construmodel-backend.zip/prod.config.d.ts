declare const _default: {
    DB_PASSWORD: string;
    DB_HOST: string;
    COOKIE_SECRET: string;
};
export = _default;
